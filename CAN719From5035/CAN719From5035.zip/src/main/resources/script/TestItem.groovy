import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.lang.Exception;

class TestItem {
	String userId;
	String startDate;
}
